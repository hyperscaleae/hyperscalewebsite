/* HyperScale Signal / Scale direction: editorial dark field, precise cobalt structure, mint conversion signals, and interaction that turns every section into a measurable next move. */
import { useEffect, useRef, useState } from "react";
import type { FormEvent, ReactNode } from "react";
import { Link } from "wouter";
import { ArrowLeft, ArrowRight, ArrowUpRight, ChevronDown, ChevronRight, CircleDot, Globe2, Mail, Menu, MessageCircle, PhoneCall, X } from "lucide-react";

const heroImage = "/manus-storage/hyperscale-hero-h-transparent-clean_8574ddfd.png";
const markImage = "/manus-storage/hyperscale-mark-symbol_896cc986.png";
const serviceImages = {
  performance: "/manus-storage/hyperscale-service-performance_9c93e907.png",
  growth: "/manus-storage/hyperscale-service-growth_57f30cef.png",
  ai: "/manus-storage/hyperscale-service-ai_4b378d2e.png",
  experience: "/manus-storage/hyperscale-service-experience_cbf20a08.png",
  creative: "/manus-storage/hyperscale-service-creative_ecf69f9c.png",
  ecommerce: "/manus-storage/hyperscale-service-ecommerce_fac3ddef.png",
};
const caseImages = {
  food: "/manus-storage/hyperscale-case-food_18d5029a.png",
  digital: "/manus-storage/hyperscale-case-digital_53fbf943.png",
  retail: "/manus-storage/hyperscale-case-retail_1a6762f7.png",
  alora: "/manus-storage/alora-restored_69b64102.png",
  leaders: "/manus-storage/leaders-restored_e8e42c91.png",
  alkhalil: "/manus-storage/al-khalil-hero_f1285839.png",
  bricks: "/manus-storage/bricks-hero_0ae816b5.png",
  zyva: "/manus-storage/zyva-hero_8ef6788f.png",
};

const clients = ["Al Khalil Group", "Alora Media", "Alora 360", "Habboba", "Leaders Care AU", "Leaders Care GC", "Meat Palace", "Meat Master One", "Tannia Poultry", "Sophia Candles", "Bashayrina Butchery", "Elite Butchery", "G.S Pets", "Emad", "Jerusalem Butchery"];
const clientLogos = [
  { name: "Alora Media", src: "/manus-storage/alora_c79eb901.png" },
  { name: "Habboba", src: "/manus-storage/habboba_d0763366.png" },
  { name: "Bashayerna", src: "/manus-storage/bashayerna_720227f6.png" },
  { name: "High Class", src: "/manus-storage/high-class_90e4604c.png" },
  { name: "Zyva Group", src: "/manus-storage/zyva_ee37e6fd.png" },
  { name: "Meat Palace", src: "/manus-storage/meat-palace_095b6868.png" },
  { name: "Gourmet", src: "/manus-storage/gourmet_e9b9010f.png" },
  { name: "Sophia Candles", src: "/manus-storage/sophia_14ad97ce.png" },
  { name: "Al Khalil", src: "/manus-storage/al-khalil_8d5caf55.png" },
];

const stages = [
  ["01", "Strategy", "Find the commercial signal before you buy the media."],
  ["02", "Creative", "Build ideas that earn attention and make value legible."],
  ["03", "Acquisition", "Deploy the right channel mix with a clear job to do."],
  ["04", "Conversion", "Remove friction from landing page to checkout."],
  ["05", "Analytics", "Measure the levers that move the business forward."],
  ["06", "Optimization", "Turn every test into a sharper next decision."],
  ["07", "Scale", "Increase what works without losing the economics."],
];

const cases = [
  { title: "Alora Media", tag: "Integrated Events & Experiential", market: "UAE", image: caseImages.alora, index: "01", description: "End-to-end digital transformation for a leading UAE experiential agency.", url: "https://aloramedia.ae/" },
  { title: "Leaders Care GC", tag: "Healthcare & Accessibility Solutions", market: "UAE", image: caseImages.leaders, index: "02", description: "Comprehensive digital catalog and positioning for a leader in accessibility and healthcare fit-outs.", url: "https://leaderscaregc.com/" },
  { title: "Al Khalil Foods", tag: "Food Wholesale & Retail", market: "UAE", image: caseImages.alkhalil, index: "03", description: "E-commerce storefront and growth system for a premier regional food distributor.", url: "https://alkhalilfoods.ae/" },
  { title: "Zyva Solutions", tag: "Financial & Business Services", market: "UAE", image: caseImages.zyva, index: "04", description: "Providing innovative business, financial and general trading solutions for the Gulf region.", url: "https://www.zyvasolutions.com/" },
  { title: "Bricks & Stones", tag: "MEP & Construction Solutions", market: "UAE", image: caseImages.bricks, index: "05", description: "High-performance engineering and construction systems for ambitious infrastructure projects.", url: "" },
];

type TestimonialSlot = { company: string; speaker: string; role: string; quote: string; logoText: string };
const testimonialSlots: TestimonialSlot[] = [
  { company: "Client story 01", speaker: "Verified quote pending", role: "Add client name & role", quote: "Your approved client quote will live here.", logoText: "CLIENT LOGO" },
  { company: "Client story 02", speaker: "Verified quote pending", role: "Add client name & role", quote: "Your approved client quote will live here.", logoText: "CLIENT LOGO" },
  { company: "Client story 03", speaker: "Verified quote pending", role: "Add client name & role", quote: "Your approved client quote will live here.", logoText: "CLIENT LOGO" },
];

function Shell({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const [servicesOpen, setServicesOpen] = useState(false);
  useEffect(() => {
    const obs = new IntersectionObserver((entries) => entries.forEach((entry) => { if (entry.isIntersecting) entry.target.classList.add("reveal-visible"); }), { threshold: 0.1 });
    document.querySelectorAll(".reveal").forEach((element) => obs.observe(element));
    return () => obs.disconnect();
  }, []);
  const links = [["Work", "/work"], ["About", "/about"], ["Insights", "/insights"]];
  const closeMenu = () => { setOpen(false); setServicesOpen(false); };
  return <div className="site-shell"><div className="scale-rail" aria-hidden="true"><span /><b>01</b><i>growth system</i></div><header className="topbar"><div className="topbar-inner"><Link href="/" className="brand" onClick={closeMenu}><img src={markImage} alt="HyperScale symbol" /><span><strong>HYPERSCALE</strong><small>Growth systems</small></span></Link><nav className={open ? "nav-open" : ""}>{links.map(([label, href]) => <Link key={href} href={href} onClick={closeMenu}>{label}</Link>)}<div className={`nav-services ${servicesOpen ? "services-open" : ""}`}><button className="nav-services-trigger" type="button" onClick={() => setServicesOpen((value) => !value)} aria-expanded={servicesOpen} aria-haspopup="true">Services <ChevronRight size={13} /></button><div className="services-mega-menu"><div className="mega-menu-intro"><span>04 / CAPABILITIES</span><strong>Build the engine<br />behind growth.</strong></div><div className="mega-menu-links"><Link href="/services" onClick={closeMenu}><span className="mega-icon"><ArrowUpRight size={14} /></span><span><strong>Performance Marketing</strong><small>Turn attention into demand.</small></span></Link><Link href="/services" onClick={closeMenu}><span className="mega-icon"><CircleDot size={14} /></span><span><strong>Growth Strategy</strong><small>Find the highest-leverage move.</small></span></Link><Link href="/services" onClick={closeMenu}><span className="mega-icon"><ChevronRight size={14} /></span><span><strong>AI &amp; Systems</strong><small>Make the machine work harder.</small></span></Link><Link href="/services" onClick={closeMenu}><span className="mega-icon"><Globe2 size={14} /></span><span><strong>Digital Experience</strong><small>Design journeys that convert.</small></span></Link></div></div></div><div className="nav-actions"><button className="nav-language" type="button"><Globe2 size={14} /> English</button><Link className="nav-expert" href="/contact" onClick={closeMenu}>Speak to an expert <ArrowUpRight size={15} /></Link><a className="nav-icon" href="mailto:hello@hyperscale.marketing" aria-label="Email HyperScale"><Mail size={16} /></a><a className="nav-icon" href="tel:+971566997831" aria-label="Call HyperScale"><PhoneCall size={16} /></a></div></nav><button className="menu-button" aria-label="Toggle menu" aria-expanded={open} onClick={() => setOpen((value) => !value)}>{open ? <X /> : <Menu />}</button></div></header>{children}</div>;
}

function SectionEyebrow({ children, number }: { children: ReactNode; number?: string }) { return <div className="eyebrow"><span>{number || "//"}</span><span>{children}</span></div>; }

function HeroForm() {
  const [sent, setSent] = useState(false);
  const handle = (e: FormEvent) => { e.preventDefault(); setSent(true); };
  if (sent) return <div className="hero-form-card sent"><h3>Message received.</h3><p>We'll find the signal together. Expect a response within 24 hours.</p></div>;
  return <div className="hero-form-card"><h3>Ready to start</h3><p>Next-level growth systems for ambitious brands.</p><form onSubmit={handle}><div className="field"><label>NAME</label><input type="text" required placeholder="Your full name" /></div><div className="field"><label>EMAIL</label><input type="email" required placeholder="name@company.com" /></div><div className="field"><label>PHONE</label><input type="tel" required placeholder="+971..." /></div><button type="submit" className="button button-mint w-full">Get your free proposal <ArrowUpRight size={17} /></button></form></div>;
}

function CaseCard(item: typeof cases[number]) {
  const isLive = Boolean(item.url);
  return (
    <article className={`case-card case-${item.index}`}>
      <div className="case-laptop-mockup">
        {isLive ? (
          <a className="laptop-screen-link" href={item.url} target="_blank" rel="noopener noreferrer" aria-label={`Visit ${item.title} website`}>
            <div className="laptop-bezel">
              <div className="laptop-camera" />
              <div className="laptop-screen">
                <img src={item.image} alt={`${item.title} website screenshot`} loading="lazy" />
              </div>
            </div>
            <div className="laptop-base" />
          </a>
        ) : (
          <div className="laptop-mockup-static">
            <div className="laptop-bezel">
              <div className="laptop-camera" />
              <div className="laptop-screen">
                <img src={item.image} alt={`${item.title} project visual`} loading="lazy" />
              </div>
            </div>
            <div className="laptop-base" />
          </div>
        )}
      </div>
      <div className="case-info">
        <div>
          <h3>{item.title}</h3>
          <p className="case-tag">{item.tag}</p>
        </div>
        {isLive && (
          <a href={item.url} target="_blank" rel="noopener noreferrer" className="case-live-btn">
            <span>Visit Site</span>
            <ArrowUpRight size={14} />
          </a>
        )}
      </div>
      <p className="case-desc">{item.description}</p>
    </article>
  );
}

function CaseStudiesRail() {
  return <section className="case-studies-section reveal" id="case-studies"><div className="case-studies-heading"><div><SectionEyebrow number="03">Case studies</SectionEyebrow><h2>Websites built<br /><em>to move business.</em></h2><p>A focused selection of HyperScale digital experiences, designed to make each brand more useful, visible and commercially ready.</p></div><Link href="/work/websites" className="case-all-link">Browse all websites <ArrowUpRight size={17} /></Link></div><div className="case-study-rail">{cases.map((c) => <CaseCard key={c.title} {...c} />)}</div></section>;
}

function TestimonialsSection() {
  return <section className="testimonials-section reveal" id="project-evidence"><div className="testimonials-heading"><div><SectionEyebrow number="06">Project evidence</SectionEyebrow><h2>Work you can<br /><em>actually explore.</em></h2><p>We keep proof simple: approved clients, visible output, and live projects where a public link is available. No invented praise or unsupported claims.</p></div><Link href="/work/websites" className="case-all-link">View website portfolio <ArrowUpRight size={17} /></Link></div><div className="evidence-grid">{cases.slice(0, 3).map((item) => <article className="evidence-card" key={item.title}><span>0{item.index} / SELECTED PROJECT</span><h3>{item.title}</h3><p>{item.tag}</p>{item.url ? <a href={item.url} target="_blank" rel="noopener noreferrer">Explore live website <ArrowUpRight size={15} /></a> : <Link href="/work/websites">View project <ArrowUpRight size={15} /></Link>}</article>)}</div></section>;
}

const serviceOptions = ["Performance Marketing", "Growth Strategy", "E-commerce Growth", "AI & Marketing Systems", "Websites & Conversion Experiences", "Creative Strategy"];
function LeadForm({ compact = false }: { compact?: boolean }) {
  const [selectedServices, setSelectedServices] = useState<string[]>([]);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState("");
  const toggleService = (service: string) => setSelectedServices((current) => current.includes(service) ? current.filter((item) => item !== service) : [...current, service]);
  const submit = (event: FormEvent<HTMLFormElement>) => { event.preventDefault(); if (!selectedServices.length) { setError("Select at least one service so we can route your enquiry."); return; } setError(""); setSubmitted(true); };
  return <form className={`growth-form ${compact ? "growth-form-compact" : ""}`} onSubmit={submit}>{submitted && <div className="form-success" role="status">Thanks. Your enquiry is ready for a real conversation. We’ll be in touch shortly.</div>}<div className="form-row"><label>Name*<input name="name" required placeholder="Your name" /></label><label>Company name*<input name="company" required placeholder="Your company" /></label></div><div className="form-row"><label>Phone number*<input name="phone" type="tel" required placeholder="+971 50 000 0000" /></label><label>Professional email*<input name="email" type="email" required placeholder="you@company.com" /></label></div><div className="form-row"><label>Monthly digital marketing budget<select name="budget" defaultValue=""><option value="" disabled>Please select</option><option value="under-5k">Under $5k</option><option value="5k-15k">$5k–$15k</option><option value="15k-50k">$15k–$50k</option><option value="50k-plus">$50k+</option></select></label><label>How can we help you?<select name="help" defaultValue=""><option value="" disabled>Please select</option><option value="launch">Launch a new offer</option><option value="scale">Scale an existing engine</option><option value="fix">Fix a conversion bottleneck</option><option value="systemize">Build a marketing system</option></select></label></div><fieldset><legend>Which service are you interested in?*</legend><div className="service-checkboxes">{serviceOptions.map((service) => <label key={service}><input type="checkbox" checked={selectedServices.includes(service)} onChange={() => toggleService(service)} /> <span>{service}</span></label>)}</div></fieldset><label>What are your business objectives and needs in digital marketing?<textarea name="objectives" rows={4} placeholder="A little context helps us come prepared." /></label><label className="privacy-check"><input type="checkbox" required /> <span>I agree to be contacted about this enquiry.</span></label>{error && <p className="form-error" role="alert">{error}</p>}<button className="button button-mint" type="submit">Send enquiry <ArrowUpRight size={17} /></button></form>;
}

function TalkGrowthSection() { return <section className="talk-growth-section reveal" id="contact"><div className="talk-growth-intro"><SectionEyebrow number="07">Let’s talk growth</SectionEyebrow><h2>Make the next move<br /><em>more deliberate.</em></h2><p>Leave the details and we’ll come prepared to discuss the opportunity, the constraints and the clearest next step.</p><div className="talk-orbit"><span>H</span><i>Growth system</i><b>UAE · KSA · GCC</b></div></div><LeadForm /></section>; }

function AdvertisingCases() {
  const adCases = [
    { client: "AL KHALIL FOODS", term: "Verified Presence", problem: "Scaling digital visibility for a premier Abu Dhabi food retail and wholesale group across multiple locations.", goal: "Establish a dominant social presence and catalog accessibility.", solution: "Coordinated content strategy across retail and wholesale segments, focusing on fresh product visibility and location-based engagement.", results: { metric1: ["10.3K", "Followers"], metric2: ["789", "Posts"], metric3: ["Verified", "Social Signal"], metric4: ["Active", "Community"] }, note: "Maintaining an active digital presence for Mussafah and Khalifa City locations with over 10,300 followers and consistent engagement." },
    { client: "HABBOBA O BAS", term: "Verified Presence", problem: "Launching and scaling the digital presence for Riyadh's first Sudanese cloud kitchen and bakery.", goal: "Drive awareness and direct orders through social channels.", solution: "Visual storytelling of authentic Sudanese cuisine, customer reviews integration, and direct-to-order funnel architecture.", results: { metric1: ["1,290", "Followers"], metric2: ["180", "Posts"], metric3: ["Cloud Kitchen", "Signal"], metric4: ["Riyadh", "Presence"] }, note: "Successfully established a niche digital presence for a specialized cloud kitchen, reaching over 1,290 followers during the initial scale phase." }
  ];
  const [activeIndex, setActiveIndex] = useState(0);
  const c = adCases[activeIndex];
  const move = (direction: number) => setActiveIndex((current) => (current + direction + adCases.length) % adCases.length);
  return <section className="ad-cases-section reveal" id="advertising"><div className="ad-cases-heading"><div><SectionEyebrow number="08">Advertising cases</SectionEyebrow><h2>Performance that speaks<br /><em>in business results.</em></h2><p>Real campaign data and social presence metrics from verified client engagements. No vanity metrics—just measurable movement.</p></div><div className="ad-case-slider-controls"><span>{String(activeIndex + 1).padStart(2, "0")} / {String(adCases.length).padStart(2, "0")}</span><button type="button" onClick={() => move(-1)} aria-label="Previous advertising case"><ArrowLeft size={17} /></button><button type="button" onClick={() => move(1)} aria-label="Next advertising case"><ArrowRight size={17} /></button></div></div><div className="ad-case-list ad-case-slider"><article className="ad-case-story" key={c.client}><div className="ad-case-visual"><div className="mockup-phone"><div className="mockup-screen"><div className="mockup-insta"><div className="insta-header"><span>{c.client.toLowerCase().replace(/\s+/g, '_')}</span><Menu size={14} /></div><div className="insta-profile"><div className="insta-avatar" /><div className="insta-stats"><span><b>{c.results.metric2[0]}</b>posts</span><span><b>{c.results.metric1[0]}</b>followers</span><span><b>{c.results.metric1[0] === '10.3K' ? '4' : '0'}</b>following</span></div></div><div className="insta-bio"><strong>{c.client}</strong><p>{c.note.split('.')[0]}</p></div><div className="insta-grid">{[1,2,3,4,5,6].map(i => <div key={i} className="insta-square" />)}</div></div></div></div></div><div className="ad-case-content"><div className="ad-case-meta"><span>"{c.client}"</span><strong>{c.term === 'Verified Presence' ? 'SOCIAL SIGNAL' : 'PERFORMANCE CASE'}</strong><small>Status: {c.term}</small></div><div className="ad-case-grid"><div><span>Point A</span><p>{c.problem}</p></div><div><span>Goal</span><p>{c.goal}</p></div><div><span>Solution</span><p>{c.solution}</p></div><div><span>The results</span><p>{c.note}</p></div></div><div className="ad-case-metrics"><div><b>{c.results.metric1[0]}</b><span>{c.results.metric1[1]}</span></div><div><b>{c.results.metric2[0]}</b><span>{c.results.metric2[1]}</span></div><div><b>{c.results.metric3[0]}</b><span>{c.results.metric3[1]}</span></div><div><b>{c.results.metric4[0]}</b><span>{c.results.metric4[1]}</span></div></div></div></article></div></section>;
}

export function HomePage() {
  return <Shell><main><section className="hero reveal"><div className="hero-copy"><SectionEyebrow number="01">Growth systems for ambitious brands</SectionEyebrow><h1>We build growth systems <em>that scale.</em></h1><p className="hero-lede">HyperScale combines performance marketing, creative strategy, AI and digital systems to help ambitious brands grow faster—and smarter.</p><div className="hero-actions"><Link href="/work" className="button button-primary">Explore our work <ArrowUpRight size={17} /></Link><Link href="/contact" className="text-link">Start a conversation <ChevronRight size={16} /></Link></div><div className="hero-foot"><span>Strategy → Execution → Data → Optimization → Scale</span><span>UAE · KSA · AUS · GCC</span></div></div><div className="hero-form-container"><HeroForm /></div></section><section className="marquee"><div>BUILT ACROSS REAL BUSINESSES <span>✳</span> REAL MARKETS <span>✳</span> REAL GROWTH CHALLENGES <span>✳</span> BUILT ACROSS REAL BUSINESSES <span>✳</span></div></section>    <section className="system-section reveal" id="process"><div className="section-intro"><SectionEyebrow number="02">Our Process</SectionEyebrow><h2>Marketing is not a collection of channels. <em>It’s a system.</em></h2><p>Good growth compounds when strategy, creative, acquisition, conversion and data are connected. That’s the layer we build.</p></div><div className="interactive-process">{stages.map(([number, title, copy]) => <div className="process-step" key={number}><div className="process-dot"><span /></div><div className="process-content"><span>Step {number}</span><h3>{title}</h3><p>{copy}</p></div></div>)}</div></section><CaseStudiesRail /><section className="services-band reveal"><div className="section-intro"><SectionEyebrow number="04">What we do</SectionEyebrow><h2>Sharper systems.<br /><em>Stronger outcomes.</em></h2><p>We build the growth systems that ambitious brands need to scale efficiently in modern markets.</p></div><div className="service-grid-premium">{[{ n: "01", t: "Performance Marketing", d: "Paid media, acquisition, funnel architecture, and performance reporting.", i: serviceImages.performance }, { n: "02", t: "Growth Strategy", d: "Strategy, CRO, offers, journeys, and experimental design.", i: serviceImages.growth }, { n: "03", t: "AI & Systems", d: "Automation, research, workflows, and internal leverage.", i: serviceImages.ai }, { n: "04", t: "Digital Experience", d: "High-converting websites and landing pages designed to perform.", i: serviceImages.experience }, { n: "05", t: "Creative Strategy", d: "Concepts, content systems, testing, and creative direction.", i: serviceImages.creative }, { n: "06", t: "E-commerce Growth", d: "Storefront optimization, cart recovery, and revenue-focused digital commerce systems.", i: serviceImages.ecommerce }].map((service) => <div className="service-card-premium" key={service.n}><div className="service-card-image"><img src={service.i} alt={service.t} /></div><div className="service-card-content"><span>{service.n}</span><h3>{service.t}</h3><p>{service.d}</p><Link href="/services" className="service-card-link">Discover more <ArrowUpRight size={14} /></Link></div></div>)}</div></section><section className="client-section reveal"><div className="client-copy"><SectionEyebrow number="05">Selected client roster</SectionEyebrow><h2>Small team.<br /><em>Real businesses.</em></h2><p>We work across food, retail, e-commerce, professional services, events and healthcare—where growth has to show up in the business.</p></div><div className="client-logo-showcase" aria-label="Selected clients"><div className="client-logo-track client-logo-track-forward">{clientLogos.map((client) => <div className="client-logo-tile" key={`forward-${client.name}`}><img src={client.src} alt={client.name} /></div>)}</div><div className="client-logo-track client-logo-track-reverse">{[...clientLogos].reverse().map((client) => <div className="client-logo-tile" key={`reverse-${client.name}`}><img src={client.src} alt={client.name} /></div>)}</div></div></section><TestimonialsSection /><AdvertisingCases /><section className="consultation-banner reveal"><div className="banner-content"><h2>Be Our Success Story</h2><p>Find out more on how we exceeded client expectations.</p></div><Link href="/contact" className="button button-mint">Book A Free Consultation <ArrowUpRight size={17} /></Link></section><TalkGrowthSection /></main><Footer /></Shell>;
}

export function WorkHubPage() {
  const categories = [
    { title: "Performance Marketing", slug: "performance", icon: <ArrowUpRight size={24} /> },
    { title: "Growth Strategy", slug: "strategy", icon: <CircleDot size={24} /> },
    { title: "E-commerce Growth", slug: "ecommerce", icon: <Globe2 size={24} /> },
    { title: "AI & Marketing Systems", slug: "ai-systems", icon: <ChevronRight size={24} /> },
    { title: "Websites & Conversion", slug: "websites", icon: <Globe2 size={24} /> },
    { title: "Creative Strategy", slug: "creative", icon: <MessageCircle size={24} /> },
  ];
  return (
    <Shell>
      <main className="inner-page work-hub">
        <div className="work-hub-intro">
          <SectionEyebrow number="01">Our Proven Impact</SectionEyebrow>
          <div className="work-hub-hero">
            <div className="work-hub-copy">
              <h1>The Proof is in<br /><em>the Growth.</em></h1>
              <p>Explore how HyperScale builds the engines that drive modern business results.</p>
              <p>We don't just execute campaigns; we build integrated growth systems. Our portfolio reflects a relentless focus on finding the commercial signal and scaling it through performance marketing, creative strategy, and technical excellence.</p>
              <p>Across food retail, e-commerce, and professional services, our work stays connected to the bottom line—transforming scattered activity into measurable movement.</p>
              <p><strong>Explore our selected cases by service below.</strong></p>
            </div>
            <div className="work-hub-visual">
              <div className="floating-orbit">
                <div className="orbit-ring" />
                <div className="orbit-ring" />
                <div className="orbit-ring" />
                <span>H</span>
              </div>
            </div>
          </div>
        </div>

        <section className="work-browse">
          <h2>Browse Our Work <em>by Service</em></h2>
          <div className="work-category-grid">
            {categories.map((cat) => (
              <Link key={cat.slug} href={`/work/${cat.slug}`} className="work-category-card">
                <span className="cat-icon">{cat.icon}</span>
                <strong>{cat.title}</strong>
              </Link>
            ))}
          </div>
        </section>
      </main>
      <Footer />
    </Shell>
  );
}

export function WorkWebsitesPage() {
  return (
    <Shell>
      <main className="inner-page work-websites">
        <div className="page-header">
          <Link href="/work" className="back-link"><ArrowLeft size={16} /> Back to Portfolio</Link>
          <SectionEyebrow number="01.1">Website Portfolio</SectionEyebrow>
          <h1>Conversion-first<br /><em>Digital Experiences.</em></h1>
          <p className="page-lede">Selected website projects, presented within a high-fidelity visual context and live links to explore the work.</p>
        </div>
        <div className="case-grid full-grid">
          {cases.map((item) => (
            <CaseCard key={item.title} {...item} />
          ))}
        </div>
      </main>
      <Footer />
    </Shell>
  );
}
export function ServicesPage() { const all = [["01", "Performance Marketing", "Paid media, campaign architecture, retargeting, funnel optimization and performance reporting."], ["02", "Growth Strategy", "Customer acquisition, conversion rate optimization, offers, journeys and experiment design."], ["03", "E-commerce Growth", "Product positioning, promotional strategy, landing pages, retention and analytics."], ["04", "AI & Marketing Systems", "AI-assisted content systems, reporting automation, research and internal workflows."], ["05", "Websites & Conversion Experiences", "High-converting websites, landing pages, UX optimization and analytics foundations."], ["06", "Creative Strategy", "Ad creative direction, campaign concepts, content systems and creative testing."]]; return <Shell><main className="inner-page services-page"><SectionEyebrow number="01">Capabilities</SectionEyebrow><h1>One system.<br /><em>Many levers.</em></h1><p className="page-lede">We connect the parts of growth that are usually separated—strategy, media, creative, experience, and the data that tells you what to do next.</p><div className="service-detail-list">{all.map(([number, title, description]) => <div key={number}><span>{number}</span><h2>{title}</h2><p>{description}</p><ArrowUpRight size={20} /></div>)}</div></main><Footer /></Shell>; }
export function AboutPage() { return <Shell><main className="inner-page about-page"><SectionEyebrow number="01">About HyperScale</SectionEyebrow><h1>A compact team<br /><em>with a systems mind.</em></h1><p className="page-lede">HyperScale exists for ambitious brands that are ready to move from scattered marketing activity to a growth system that compounds.</p><div className="about-columns"><div><p>We sit at the intersection of performance marketing, creative execution, technology and commercial strategy. That means fewer handoffs, clearer decisions and work that stays connected to the business.</p><p>Our role is not to make more noise. It is to find the signal, build the right engine around it, and keep improving the system as the market changes.</p></div><div className="principles"><span>01 — Clear thinking</span><span>02 — Useful creativity</span><span>03 — Measured movement</span><span>04 — Relentless iteration</span></div></div></main><Footer /></Shell>; }
export function InsightsPage() { const items = [["Growth systems", "Why the best performance work starts before the campaign goes live."], ["Creative testing", "A practical way to turn creative into a learning engine."], ["AI & leverage", "Where automation creates capacity—and where it creates noise."]]; return <Shell><main className="inner-page"><SectionEyebrow number="01">Insights</SectionEyebrow><h1>Sharper thinking for<br /><em>the next move.</em></h1><p className="page-lede">Notes on growth, creative, systems and the decisions behind work that compounds.</p><div className="insight-list">{items.map(([tag, title], index) => <article key={title}><span>0{index + 1} / {tag}</span><h2>{title}</h2><a href="#contact">Read the note <ArrowUpRight size={16} /></a></article>)}</div></main><Footer /></Shell>; }
export function ContactPage() { return <Shell><main className="inner-page contact-page"><SectionEyebrow number="01">Start a conversation</SectionEyebrow><h1>Let’s talk<br /><em>growth.</em></h1><p className="page-lede">Share the context and we’ll come prepared to discuss your next stage of growth.</p><LeadForm compact /></main><Footer /></Shell>; }

function Footer() { return <><footer className="premium-footer"><div className="footer-hero"><Link href="/" className="footer-mark"><img src={markImage} alt="HyperScale symbol" /><span><strong>HYPERSCALE</strong><small>Growth systems</small></span></Link><p>Build. Optimize. Scale.</p><div className="footer-socials"><a href="mailto:hello@hyperscale.marketing" aria-label="Email HyperScale"><Mail size={17} /></a><Link href="/work" aria-label="View our work"><ArrowUpRight size={17} /></Link><Link href="/contact" aria-label="Start a conversation"><Globe2 size={17} /></Link></div></div><div className="footer-rule" /><div className="footer-grid"><div className="footer-column footer-contact"><h3>Contact us</h3><p>Let’s talk about the next stage of growth for your business.</p><a href="mailto:hello@hyperscale.marketing">hello@hyperscale.marketing <ArrowUpRight size={15} /></a><Link href="/contact" className="footer-contact-link">Start a conversation <ArrowUpRight size={15} /></Link></div><div className="footer-column"><h3>Overview</h3><Link href="/about">About HyperScale</Link><Link href="/services">Services</Link><Link href="/work">Our work</Link><Link href="/insights">Insights</Link><Link href="/contact">Contact</Link></div><div className="footer-column"><h3>Growth systems</h3><Link href="/services">Performance marketing</Link><Link href="/services">Growth strategy</Link><Link href="/services">E-commerce growth</Link><Link href="/services">AI &amp; marketing systems</Link><Link href="/services">Digital experience</Link><Link href="/services">Creative strategy</Link></div><div className="footer-column"><h3>Focus markets</h3><span>Food &amp; beverage</span><span>Retail &amp; e-commerce</span><span>Professional services</span><span>Events &amp; experiential</span><span>Healthcare &amp; accessibility</span><span>UAE · KSA · AUS · GCC</span></div></div><div className="footer-bottom"><span>© 2026 HyperScale</span><span>Growth systems for ambitious brands.</span><span>Made for measurable movement.</span></div></footer><div className="floating-contact" aria-label="Quick contact"><a className="floating-whatsapp" href="https://wa.me/971566997831" target="_blank" rel="noreferrer" aria-label="Chat with HyperScale on WhatsApp"><MessageCircle size={21} strokeWidth={2.4} /></a><a className="floating-phone" href="tel:+971566997831" aria-label="Call HyperScale"><PhoneCall size={17} /></a></div></>; }

export default HomePage;
